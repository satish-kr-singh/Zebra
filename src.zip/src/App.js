import React from "react";
import "./main.css";
import { BsFillPlusCircleFill,BsThreeDotsVertical ,BsMenuButtonWide} from "react-icons/bs"

export default class App extends React.Component {
  render() {
    return (
      <div>
      <div className='Rectangle'>
        <div className='Rectangle-menu'>
          <button>
            <BsMenuButtonWide style={{ width: "25px", height: "25px" }} />
          </button>
        </div>
        <div className='title-text Rectangle-menu'>
          Cat-a-log
        </div>
        <div className='Rectangle-menu' style={{position:'relative',left:'160px'}}>
          <button>
            <BsThreeDotsVertical style={{ width: "25px", height: "25px" }} />
          </button>
        </div>
      </div>
      <div>
      <img src='http://placekitten.com/200/300' alt='No Image' className='img-Kitten'></img>
      </div>
      <div style={{position:'relative', left:'61%', zIndex:9,margin:'-19px 1px'}}>
          <button >
            <BsFillPlusCircleFill style={{ width: "25px", height: "25px" }} />
          </button>
        </div>
    </div>
    );
  }
}